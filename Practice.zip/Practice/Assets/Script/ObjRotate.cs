﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjRotate : MonoBehaviour {

	public float rotationSpeed = 10;  //This will determine max rotation speed, you can adjust in the inspector

	void OnMouseDrag() {
		float rotX = Input.GetAxis ("Mouse X") * rotationSpeed * Mathf.Deg2Rad;

		transform.RotateAround (Vector3.up, -rotX);

	}

	/*public Camera cam;  //Drag the camera object here

	void Update()
	{
		//RotateObject();
	}

	void RotateObject()
	{
		//Get mouse position
		Vector3 mousePos = Input.mousePosition;

		//Adjust mouse z position
		mousePos.z = cam.transform.position.y - transform.position.y;   

		//Get a world position for the mouse
		Vector3 mouseWorldPos = cam.ScreenToWorldPoint(mousePos);   

		//Get the angle to rotate and rotate
		float angle = -Mathf.Atan2(transform.position.z - mouseWorldPos.z, transform.position.x - mouseWorldPos.x) * Mathf.Rad2Deg;
		transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, angle, 0), rotationSpeed * Time.deltaTime);
	}*/

}
